import React from 'react';

const Board = () => {
    return (
        <div>
            게시판 구현 공간
        </div>
    );
};

export default Board;