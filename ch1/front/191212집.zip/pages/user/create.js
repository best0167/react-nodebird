import React from 'react';
import Link from 'next/link';

const Create = () => {
    return (
        <div>about!</div>
    );
};

export default About;